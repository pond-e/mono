#!/usr/bin/env python
#!C:/Python27/python

# ## Copyright (c) 2013
# Tokyo COSMOS Electric, Inc.
# All rights reserved.

# ## Copyright (c) 2011
# Telecooperation Office (TecO), Universitaet Karlsruhe (TH), Germany.
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following
#    disclaimer in the documentation and/or other materials provided
#    with the distribution.
# 3. Neither the name of the Universitaet Karlsruhe (TH) nor the names
#    of its contributors may be used to endorse or promote products
#    derived from this software without specific prior written
#    permission.
# 
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
# A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
# OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
# LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
# DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
# THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
# (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
# 
# Author(s): Philipp Scholl <scholl@teco.edu>

from optparse import *
from time import time
from sys import stdout, stderr, exit
from os import SEEK_END, SEEK_SET, chdir, getcwd

from struct import pack

#
# version
#
version = "1.3"

#
# boot display
#
stderr.write("*** jenprog ver %s ***\n" % version)

#
# force exit at an error
#
err_code = 0
def error_exit(status=2, msg=""):
    global err_code
    stderr.write("\nERROR(%d): %s\n" % (status, msg))
    err_code = status
    exit(err_code)

#
# show information
#
def bl_show (bl):
    stdout.write("  flash   : %s %s\n" % (bl.flash_manufacturer, bl.flash_type))
    # stdout.write("  chipid: %08x"%(bl.read_chipid()))
    # stdout.write(bl.read_chipid()[0])
    bl.read_chipid()
    stdout.write("  chip id : 0x%08x\n" % bl.chipid)
    
    stdout.write("  mac addr: 0x")
    for b in bl.read_mac(): stdout.write("%02x" % b)
    stdout.write("\n")

    if bl.flash_jennicid == 0x8:
        lic = bl.read_license()
        if not lic == None:
            stdout.write("  license : 0x")
            for b in bl.read_license(): stdout.write("%02x" % b)
            stdout.write("\n")


#
# arg parameters
#

# conns  = ('serial', 'ipv6', 'ftdi')
parser = OptionParser()
parser.add_option('-a', '--address', dest='addr', type='int',
                  help='start reading at address', metavar='ADDR', default=0x00000000)
parser.add_option('-l', '--len', dest='len', type='int',
                  help='number of bytes to read', metavar='LEN', default=0)
parser.add_option('-m', '--mac', dest='mac',
                  help='reset the mac addr (e.g. -m 01234567ABCDABCD)')
parser.add_option('-k', '--key', dest='key',
                  help='reset the license key')
# parser.add_option('-v', '--verbose', action='store_true', dest='verbose',
#                  help='print send and received packets')
parser.add_option('-v', '--verify', action='store_true', dest='verify',
                  help='also verify after writing')
parser.add_option('-z', '--compare', action='store_true', dest='verify_no_write',
                  help='compare between flash content and specified file')
parser.add_option('-s', '--show', dest='show', action='store_true',
                  help='show mac address and license key')
parser.add_option('-e', '--erase', dest='erase', action='store_true',
                  help='erasing the flash after reading mac and license key')
# parser.add_option('-c', '--connection', type='choice', dest='conn', default='serial', choices=conns,
#                  help='connection implementation ('+",".join(conns)+') [default: %default]')
parser.add_option('-b', '--baud', dest='baud', type='int',
                  help='baud rate for serial connection.', metavar='BAUD', default=500000)
parser.add_option('-t', '--target', type='string', help='target for connection', dest='target')
# parser.add_option('--reset-pin', type='int', help='pin number of reset line for ftdi-type connections (default=5)',
#                  default=5, dest='RESET')
# parser.add_option('--spimiso-pin', type='int', help='pin number of spimiso line for ftdi-type connections (default=4)',
#                  default=4, dest='SPIMISO')
parser.add_option('-F', '--force', action='store_true', dest='force',
                  help='skip firmware compatibility')
parser.add_option('-C', '--list-com-ports', action='store_true', dest='lscom',
                  help='skip firmware compatibility')
parser.add_option('-D', '--current_dir', dest='cdir',
                  help='current directory')
(options, args) = parser.parse_args()

#
# change dir (for OS X, py2app forces change dir, so relative file path name cannot be specified.)
#
if options.cdir:
    chdir(options.cdir)
    stderr.write("CHDIR: %s\n" % getcwd())

#
# check if target is specified, or list com devices.
#
if options.lscom or options.target == None:
    import con_serial
    ports = con_serial.list_serial_ports()
    print "Found ports:"
    for n in ports: print "%s" % n

    exit(2)
    
#
# Open the port.
#
options.conn = 'serial'
bl = None
if options.conn == 'serial':
    import con_serial
    from serial.serialutil import SerialException
    try:
        bl = con_serial.SerialBootloader(options.target, baud=options.baud)
    except TypeError, detail:
        error_exit(2, "communicate with the target")
    except SerialException, detail:
        error_exit(2, "access the serial port")
# elif options.conn=='ipv6':
#    import con_ipv6
#    bl = con_ipv6.IPBootloader(options.target)
# elif options.conn=='ftdi':
#    import con_ftdi
#    bl = con_ftdi.FtdiBootloader(RESET=options.RESET, SPIMISO=options.SPIMISO)
else:
    raise Exception('nahh')

# if options.verbose: bl.isverbose = True

#
# Select the actions:
#
if options.show:
    bl_show(bl)
    
elif options.erase:
    bl.erase_flash_full()
    bl_show(bl)

elif len(args) != 1:
    if options.len > 0:
        # set binary output mode for Windows system (0x0a is converted 0x0d 0x0a.)
        import sys
        if sys.platform == "win32":
            import os, msvcrt
            msvcrt.setmode(sys.stdout.fileno(), os.O_BINARY)
        
        # read data
        block, i, start = bl.preferedblocksize or 0xf0, 0, time()
        for addr in xrange(options.addr, options.addr + options.len, block):
            for byte in bl.read_flash(addr, block):
                stdout.write("%c" % byte)
                # stdout.write(pack("<B",byte))

            if addr > ((options.addr + options.len) / 10.*i):
                stderr.write("%i%%.." % (i * 10))
                i += 1

        kb, sec = options.len / 1000., (time() - start)
        stderr.write("done - %0.2f kb/s\n" % (kb / sec))

    elif options.mac or options.key:
        if bl.flash_jennicid == 0x8:
            # for JN516x
            stderr.write("MAC Update is not supported.")
        else:
            if options.mac:
                bl.set_mac(options.mac)
            if options.key:
                bl.set_license(options.key)
    
            # erase sector #0 before writing
            bl.erase_flash([0])
    
            if options.mac:
                bl.write_mac()
            if options.key:
                bl.write_license()
                    
            stderr.write("MAC/Lic was updated as below...\n")
            bl_show(bl)

    else:
        bl_show(bl)
        
    exit(0)

# with firmware programming
else:
    file = None
    try:
        file = open(args[0], "rb")
    except:
        error_exit(2, "file access.");

    # read the file size and file content
    wdata = None
    if bl.flash_jennicid == 0x8:
        # read bin size
        file.seek(0, SEEK_END)
        size = file.tell() - 4
        
        # the first four bytes are arch in compile.
        file.seek(0, SEEK_SET)
        fhead = file.read(4)
        
        flash_size = ord(fhead[0])
        ram_size = ord(fhead[1])
        chip_type = ord(fhead[2]) << 8 | ord(fhead[3])
        
        stderr.write(" file info: %02x %02x %04x\n" % (flash_size, ram_size, chip_type))
        
        # check if the binary is for JN5164
        if options.force:
            pass
        else:
            if not (flash_size == 0x04 and ram_size == 0x03 and chip_type == 0x0008):  # JN5164
                error_exit(2, "unsupported binary for JN5164, use -F option.") 
            
        # read firmware content.
        file.seek(4, SEEK_SET)
        wdata = file.read(size)
        file.seek(4, SEEK_SET)
    else:
        file.seek(0, SEEK_END)
        size = file.tell()
        file.seek(0, SEEK_SET)
        wdata = file.read(size)
        file.seek(0, SEEK_SET)
        
        # check if the binary is correct format
        if options.force:
            pass
        else:
            # check header in magic number (for JN5148)
            m = []
            for x in [0x2, 0x3, 0xc, 0xd, 0xe, 0xf]:
                m.append(ord(wdata[x])) 
            if m != [ 0xE0, 0xE0, 0x01, 0x06, 0x00, 0x35 ]:
                error_exit(2, "unsupported binary for JN5148, use -F option.")

    # check mac, lic option (JN5148)
    if not bl.flash_jennicid == 0x8:
        if options.mac:
            bl.set_mac(options.mac)
        if options.key:
            bl.set_license(options.key)
    
    # start reading the file, 0x80 seems to be the only blocksize
    # working for the jennic bootloader with certain flashtypes
    block, i, start = bl.preferedblocksize or 0x80, 0, time()
    data = file.read(block)
    addr = 0x00000000

    try:
        exit_status = None

        if not options.verify_no_write:
            # ## program flash content
            
            # erase_flash gets the mac and license key prior to doing
            # its opertation.
            # ToCos: erase necessary sector(s) only. 
            #  the firmware stored from sector #0 to #1 according to its size.
            if bl.flash_jennicid == 0x8:
                # for JN516x (so far full flash erase)
                bl.erase_flash_full()
            else:
                # quick erase...
                if size > 64 * 1024:
                    bl.erase_flash([0, 1])  # erase sector #0,1
                else:
                    bl.erase_flash([0])  # erase only sector #0
    
            # issue a write_init command if the boot loader supports
            # that.
            # if hasattr(bl, 'write_init'):
            #    bl.write_init(size)
                
            stderr.write("writing...\n  ")
            while len(data) != 0:
                # if hasattr(bl, 'write2_flash'):
                #    bl.write2_flash(addr, data)
                # else:
                #    bl.write_flash(addr, data)
                   
                bl.write_flash(addr, data)
                addr += len(data)
                data = file.read(block)
    
                if addr > (size / 10.*i):
                    stderr.write("%i%%.." % (i * 10))
                    i += 1
    
            kb, sec = size / 1000., (time() - start)
            stderr.write("done - %0.2f kb/s\n" % (kb / sec))
    
            if not bl.flash_jennicid == 0x8:
                # only for JN5148
                stderr.write("writing mac address and key...")
                bl.write_mac()
                bl.write_license()
                
            bl.finish()
            stderr.write("done\n")

        # veryfy
        if options.verify or options.verify_no_write:
            stderr.write("verifying...\n  ")
                    
            # prepare bin file data array.
            wdata_ord = size * [0]
            ct = 0
            while ct < size:
                wdata_ord[ct] = ord(wdata[ct])
                ct = ct + 1
        
            if not bl.flash_jennicid == 0x8:
                # only for JN5148
                mac = bl.read_mac()
                lic = bl.read_license()
    
                # copy MAC addr region.
                ct = 0
                for x in bl.mac_region:
                    wdata_ord[x] = mac[ct]  # comment out if you want a veryfy error.
                    ct = ct + 1
            
                # copy lic region.
                ct = 0
                for x in bl.lic_region:
                    wdata_ord[x] = lic[ct]
                    ct = ct + 1
                
            # read from flash and compare with bin file.
            i, ct, errct, block, start = 0, 0, 0, 0xf0, time()
            for adr in xrange(0x00000000, size, block):
                for byte in bl.read_flash(adr, block):
                    ct = ct + 1
                    if ct <= size:
                        if wdata_ord[ct - 1] != byte:
                            error_exit(1, "NG: VERIFY ERROR")
                        
                        if ct > (size / 10.*i):
                            stderr.write("%i%%.." % (i * 10))
                            i += 1

            kb, sec = size / 1000., (time() - start)
            stderr.write(": %0.2f kb/s\n" % (kb / sec))

        if options.mac or options.key: 
            stderr.write("MAC/Lic was updated as below...\n")
            bl_show(bl)
    
    except SystemExit:
        # if exit() is called, the exit code shall be re-specified.
        global exit_code
        exit(err_code)

    except:
        error_exit(2, "communication with the target")

    else:
        stderr.write("\nOK: firmware is successfully programmed.\n")
        exit(0)

