jenprog 簡易解説

■ オプション
  -a ADDR, --address=ADDR
                        start reading at address
                        |読み取りアドレス
  -l LEN, --len=LEN     number of bytes to read 
                        |読み込みバイト数
  -m MAC, --mac=MAC     reset the mac addr (e.g. -m 01234567ABCDABCD) 
                        |フラッシュ領域の mac アドレスの設定を行います。 
                        |※通常は書き換え禁止OTP領域にアドレスが記載されているので、本指定に意味はありません。)
  -k KEY, --key=KEY     reset the license key
                        |ライセンスキー情報の設定
  -v, --verify          also verify after writing
                        |ファームウェア書き込み後にべリファイを行います
  -z, --compare         compare between flash content and specified file
                        |指定ファイルとフラッシュの内容を比較する
  -s, --show            show mac address and license key
                        |アドレス情報などの表示
  -e, --erase           erasing the flash after reading mac and license key
                        |フラッシュ内容の消去
  -b BAUD, --baud=BAUD  baud rate for serial connection.
                        |-b 38400 のみ有効。デフォルトの低速度で UART 通信する
  -t TARGET, --target=TARGET
                        target for connection
                        |通信先デバイス 例：COM4, /dev/ttyUSB0
  -F, --force           skip firmware compatibility
                        |バイナリヘッダ情報が違っていても書き込みを行う
  
■ MAC アドレスの表示 
  # jenprog -t /dev/ttyUSB0 -s
    flash   : ST M25P40
    chip id : 0x10804686
    mac addr: 0x001bc501207015da

■ MAC アドレスの書き込み
  # jenprog -t /dev/ttyUSB0 -m 11223344AABBCCDD
  erasing sect #0 ...
  MAC/Lic was updated as below...
    flash   : ST M25P40
    chip id : 0x10804686
    mac addr: 0x001bc501207015da

■ ファームウェアの書き込み
  # jenprog -t /dev/ttyUSB0 SmplTag_Coord_JN5148_200_0.bin
  writing...
    0%..10%..20%..30%..40%..50%..60%..70%..80%..90%..done - 5.79 kb/s
  writing mac address and key...done

  OK: firmware is successfully programmed.

■ ファームウェアの書き込み+べリファイ 
  # jenprog -t /dev/ttyUSB0 -v SmplTag_Coord_JN5148_200_0.bin
  erasing sect #0 ...
  writing...
    0%..10%..20%..30%..40%..50%..60%..70%..80%..90%..done - 5.78 kb/s
  writing mac address and key...done
  verifying...
    0%..10%..20%..30%..40%..50%..60%..70%..80%..90%..done - 9.69 kb/s

  OK: firmware is successfully programmed.

■ ファームウェアのべリファイのみ
  # jenprog -t /dev/ttyUSB0 -z SmplTag_Coord_JN5148_200_0.bin
    verifying...
    0%..10%..20%..30%..40%..50%..60%..70%..80%..90%..done - 9.69 kb/s

  OK: firmware is successfully programmed.