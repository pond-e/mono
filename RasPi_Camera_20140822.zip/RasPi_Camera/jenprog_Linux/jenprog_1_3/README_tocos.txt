[jenprog-1.3] (24-Apr-2013)
  - build with py2exe.
  - added '-x' option to compare between flash content and specified file.
  - added '-b 38400' option to set 38400bps mode. (default baud of JN51xx bootloader)
  - support on JN5164 device.

[jenprog-1.2-t2] (23-Jul-2012)
ToCos modified the following part:
  - optimize timeout setting. longer time out is only necessary for flash erase.
  - implement verify option
  - can specify MAC address during firmware writing. (co-use of -m option)
  - remove ser.open() method at serial port initialization.
    (cause an exception of `already opened' at some system. e.g. Win/Mac)
  - improve exception handling.
    normal errors (such as port open, file open, target communication) will be handled
    at except clause to suppress messy error trace messages.
  - change baud rate at 500000bps from 1000000bps.
    (The best compromise is 115200 or 250000bps in program speed and serial signal
     stability, but re-connection is not work at the baudrate above.
     maybe, if the device is set at slower speed less than 250000bps, the baudrate
     command massage in 38400bps will confuse the target device.)

[jenprog-1.2-t1] (12-Jul-2012)
ToCos modified the following part:

  - instead of erasing full flash area, it will erase necessary sector (#0 or #1) only,
    which speeds up firmware programming or reserve unused sectors. (12-Jul-2012).

  note: this modification only consider `con_serial' only. the other interface may not work.
