tweusb ユーティリティ (20140729)
　　　　　　　　　　　　　　　　　　　　　　　　　　　　　　東京コスモス電機株式会社

＊本ユーティリティは無保証・無サポートです＊

本ユーティリティは、ToCoStick, TWE-Lite R のリセット・プログラムモードをコマンドラインから
制御します。

1. 動作要件
本ユーティリティの実行には以下が必要です。
- FTDI の VCP ドライバを導入されていること
- sudo コマンドを実行できること

動作確認は Raspbian 3.10.25+ で実施しています。

2. 使用方法
  ユーティリティ実行前に FTDI のドライバを unload しておきます。
  $ sudo rmmod ftdi_sio
  $ sudo rmmod usbserial

2.1 デバイスのリスト (-l)
  FTDI チップの搭載されたUSBデバイスが列挙されます。列挙には数秒かかることがあります。
  出力は ID,シリアル番号(S/N),デバイス記述 となり、デバイス記述が TWE-Lite-USB などで
  あれば制御可能と考えてください。

  $ ./tweusb -l
  # TWEUSB device list (num=2)
  # ID,S/N,Desc
  0,AHWZRBS5,TWE-Lite-USB
  1,AHWZDAFC,TWE-Lite-USB

2.2 デバイスのリセット (-r)
  TWEモジュールをリセットします。
  パラメータは ID またはシリアル番号を指定します。成功すればシリアル番号が標準出力に表示されます。
  
  ・ID を指定する方法 (1桁、2桁の整数)
  $ ./tweusb -r 0
  AHWZRBS5
  
  ・シリアル番号
  $ ./tweusb -r AHWZRBS5
  AHWZRBS5

2.3 デバイスをプログラムモードにする (-p)
  TWEモジュールをプログラムモードに設定します。
  パラメータは ID またはシリアル番号を指定します。成功すればシリアル番号が標準出力に表示されます。
  
  ・ID を指定する方法 (1桁、2桁の整数)
  $ ./tweusb -p 0
  AHWZRBS5
  
  ・シリアル番号
  $ ./tweusb -p AHWZRBS5
  AHWZRBS5

3. コンパイル
  D2XX ドライバより以下をコピーしておきます。
  	WinTypes.h
  	ftd2xx.h
  	libftd2xx.a (Raspberry Pi(ARM)用)
  	
  make します。
