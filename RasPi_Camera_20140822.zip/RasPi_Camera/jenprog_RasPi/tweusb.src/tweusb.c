/****************************************************************************
 * (C) Tokyo Cosmos Electric, Inc. (TOCOS) - 2014 all rights reserved.
 *
 * Condition to use: (refer to detailed conditions in Japanese)
 *   - The full or part of source code is limited to use for TWE (TOCOS
 *     Wireless Engine) as compiled and flash programmed.
 *   - The full or part of source code is prohibited to distribute without
 *     permission from TOCOS.
 *
 * 利用条件:
 *   - 本ソースコードは、別途ソースコードライセンス記述が無い限り東京コスモス電機が著作権を
 *     保有しています。
 *   - 本ソースコードは、無保証・無サポートです。本ソースコードや生成物を用いたいかなる損害
 *     についても東京コスモス電機は保証致しません。不具合等の報告は歓迎いたします。
 *   - 本ソースコードは、東京コスモス電機が販売する TWE シリーズ上で実行する前提で公開
 *     しています。他のマイコン等への移植・流用は一部であっても出来ません。
 *
 ****************************************************************************/

/****************************************************************************/
/***        Include files                                                 ***/
/****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include "ftd2xx.h"

#define OPER_RESET 1
#define OPER_PROG 2

/**
 * FTDI 関連のデバイスをリストアップする
 * - デバイスドライバが unload されていないとうまく行かない
 * - OS X ではこの手続きは非常に低速である
 */
void vListFTDIDevices() {
	FT_STATUS ftStatus;
	FT_HANDLE ftHandleTemp;
	DWORD numDevs;
	DWORD Flags;
	DWORD ID;
	DWORD Type;
	DWORD LocId;
	char SerialNumber[16];
	char Description[64];

	//
	// create the device information list
	//
	ftStatus = FT_CreateDeviceInfoList(&numDevs);
	if (ftStatus == FT_OK) {
		fprintf(stderr, "# TWEUSB device list (num=%d)\n", numDevs);
		fprintf(stderr, "# ID,S/N,Desc\n");
	}

	//
	// get information for device 0
	//
	int i;
	for (i = 0; i < (int)numDevs; i++) {
		ftStatus = FT_GetDeviceInfoDetail(i, &Flags, &Type, &ID, &LocId, SerialNumber, Description, &ftHandleTemp);
		if (ftStatus == FT_OK) {
		   printf("%d,%s,%s\n", i, SerialNumber,Description);
		}
	}
}

/**
 * FTDI 関連のデバイスをリストアップする
 * - デバイスドライバが unload されていないとうまく行かない
 * - この手続きはデバイスをオープンする
 */
int iListFTDIDevices2() {
	FT_STATUS ftStatus;
	FT_HANDLE ftHandle;
	FT_DEVICE ftDevice;
	DWORD numDevs;
	DWORD ID;
	char SerialNumber[16];
	char Description[64];

	//
	// create the device information list
	//
	ftStatus = FT_ListDevices(&numDevs,NULL,FT_LIST_NUMBER_ONLY);
	if (ftStatus == FT_OK) {
	    // FT_ListDevices OK, number of devices connected is in numDevs
		fprintf(stderr, "# TWEUSB device list (num=%d)\n", numDevs);
		fprintf(stderr, "# ID,S/N,Desc\n");
	} else {
		fprintf(stderr, "error:FT_ListDevices\n");
		return -1;
	}

	//
	// get information for device 0
	//
	int i;
	for (i = 0; i < (int)numDevs; i++) {
		ftStatus = FT_Open(i, &ftHandle);
		if(ftStatus == FT_OK) {
			ftStatus = FT_GetDeviceInfo(
						 ftHandle,
						 &ftDevice,
						 &ID,
						 SerialNumber,
						 Description,
						 NULL
			);

			if (ftStatus == FT_OK) {
			   printf("%d,%s,%s\n", i, SerialNumber, Description);
			} else {
				fprintf(stderr, "error:FT_Open\n");
			}

			FT_Close(ftHandle);
		}
	}

	return numDevs;
}

/**
 * シリアル番号を表示する
 */
void vDispSerial(FT_HANDLE ftHandle) {
	if (ftHandle != NULL) {
		FT_STATUS ftStatus;
		FT_DEVICE ftDevice;
		DWORD ID;
		char SerialNumber[16];
		char Description[64];

		ftStatus = FT_GetDeviceInfo(
					 ftHandle,
					 &ftDevice,
					 &ID,
					 SerialNumber,
					 Description,
					 NULL
		);

		if (ftStatus == FT_OK) {
			printf("%s", SerialNumber);
		}
	}
}

/**
 * ヘルプメッセージの表示
 */
void dispUsage() {
	fprintf(stderr, "Usage: tweusb -l              : list S/Ns\n");
	fprintf(stderr, "       tweusb -r [ID or S/N]  : reset\n");
	fprintf(stderr, "       tweusb -p [ID or S/N]  : program mode\n");
	fprintf(stderr, "  * Unload FTDI driver before running.\n");
	fprintf(stderr, "    unload -> sudo rmmod ftdi_sio\n");
	fprintf(stderr, "              sudo rmmod usbserial\n");
	fprintf(stderr, "    load   -> sudo modprobe usbserial\n");
	fprintf(stderr, "              sudo modprobe ftdi_sio\n");
}

/**
 * メインルーチン
 */
int main(int argc, char *argv[])
{
	FT_STATUS	ftStatus;
	FT_HANDLE	ftHandle;
	char *strSN = NULL;
	
	/*	引数の読み込み	*/
	int iOperation = 0;
	if(argc > 2) {
		if (!strcmp(argv[1], "-r")) {
			iOperation = OPER_RESET;
		}
		if (!strcmp(argv[1], "-p")) {
			iOperation = OPER_PROG;
		}
		strSN = argv[2];
	} else {
		if (argc > 1 && !strcmp(argv[1], "-l")) {
			iListFTDIDevices2();
			return 1;
		}
		if (argc > 1 && !strcmp(argv[1], "-L")) {
			vListFTDIDevices();
			return 1;
		}
	}

	if (0 == iOperation) {
		dispUsage();
		return 1;
	}
	
	/*	指定したシリアルポートを開ける	*/
	if (strlen(strSN) <= 2) {
		ftStatus = FT_Open(atoi(strSN), &ftHandle);
	} else {
		ftStatus = FT_OpenEx(strSN, FT_OPEN_BY_SERIAL_NUMBER, &ftHandle);
	}
	if(ftStatus != FT_OK) {
		/* 
			This can fail if the ftdi_sio driver is loaded
		 	use lsmod to check this and rmmod ftdi_sio to remove
			also rmmod usbserial
		 */
		fprintf(stderr, "FT_Open(%s) failed with status %d.\n", strSN, ftStatus);
		return 1;
	} else {
	if (strlen(strSN) <= 2) {
			printf( "%d", atoi(strSN) );
		} else {
			vDispSerial(ftHandle);
		}
	}

	/* BitBang 制御 */
	if (OPER_RESET == iOperation) {
		/*	BitBang の制御を行う(RESET) */
		FT_SetBitMode(ftHandle, 0xFB, 0x20);	// RESET
		usleep(30000);

		FT_SetBitMode(ftHandle, 0xFF, 0x20);	// RELEASE
		usleep(30000);
	} else if (OPER_PROG == iOperation) {
		/*	BitBang の制御を行う(RESET) */
		FT_SetBitMode(ftHandle, 0xF3, 0x20);	// RESET & PROGRAM
		usleep(30000);

		FT_SetBitMode(ftHandle, 0xF7, 0x20);	// PROGRAM
		usleep(30000);

		FT_SetBitMode(ftHandle, 0xFF, 0x20);	// RELEASE
		usleep(30000);
	}

	/* Now restore original mode, so that other tests work correctly. */
	FT_Close(ftHandle);
	
	return 0;
}

